<?php
    define('URL', 'http://localhost/web/nuestrocaminoasantiago/v4/');    //define la ruta base
    define('HOST', 'localhost');    //servidor de base de datos
    define('DB','u738966959_users_regs');             //seleccion de la base de datos
    define('USER', 'u738966959_audio_roots');         //Define usuario de MySql
    define('PSSWD', '12345678aA');  //CONTRASEÑ
    define('CHARSET', 'utf8mb4');   //Define el charset
?>