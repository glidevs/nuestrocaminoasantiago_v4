<!DOCTYPE html>
<html data-bs-theme="light" lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
        <title>Nuestro Camino a Santiago</title>
        <link rel="stylesheet" href="<?php echo constant('URL');?>public/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet"
              href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i&amp;display=swap">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Akshar&amp;display=swap">
        <link rel="stylesheet" href="<?php echo constant('URL');?>public/css/styles.min.css">
           <!--ICONOS-->
        <link href="<?php echo constant('URL');?>public/fonts/css/fontawesome.min.css" rel="stylesheet">
        <link href="<?php echo constant('URL');?>public/fonts/css/brands.css" rel="stylesheet">
        <link href="<?php echo constant('URL');?>public/fonts/css/solid.css" rel="stylesheet">
        <link rel="shortcut icon" href="<?php echo constant('URL');?>public/img/favicon.png">
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    </head>

    <body style="font-family: Akshar, sans-serif;">
        <nav class="navbar navbar-expand-lg fixed-top bg-body clean-navbar navbar-light top-bottom-padding">
            <div class="container">
                <a class="navbar-brand logo" href="index.php">
                    <img data-bss-disabled-mobile="true" data-aos="flip-left" class="logo-img-inicio" src="<?php echo constant('URL');?>public/img/Inicio/logo_001.png">
                    <img data-bss-disabled-mobile="true" class="pulse animated eslogan-inicio-navbar" src="<?php echo constant('URL');?>public/img/Inicio/eslogan_001.jpg">
                </a>
                <button data-bs-toggle="collapse" class="navbar-toggler" data-bs-target="#navcol-1">
                    <span class="visually-hidden">Toggle navigation</span>
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navcol-1">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" data-bss-disabled-mobile="true" data-aos="slide-right" href="<?php echo constant('URL');?>main"><i class="fa-solid fa-house"></i> home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bss-disabled-mobile="true" data-aos="slide-right" href="<?php echo constant('URL');?>nosotros">nosotros</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bss-disabled-mobile="true" data-aos="slide-right" href="<?php echo constant('URL');?>etapas">etapas</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bss-disabled-mobile="true" data-aos="slide-right" href="<?php echo constant('URL');?>galeria">galerÍa</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bss-disabled-mobile="true" data-aos="slide-right" href="<?php echo constant('URL');?>contacto">contacto</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bss-disabled-mobile="true" data-aos="slide-right" href="<?php echo constant('URL');?>recomendaciones">recomendaciones</a>
                        </li>
                        <li class="nav-item icon-mail-navbar">
                            <a class="nav-link" data-bss-disabled-mobile="true" data-aos="slide-left" href="link.html"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 20 20" fill="none">
                                <path d="M2.00333 5.88355L9.99995 9.88186L17.9967 5.8835C17.9363 4.83315 17.0655 4 16 4H4C2.93452 4 2.06363 4.83318 2.00333 5.88355Z" fill="currentColor"></path>
                                <path d="M18 8.1179L9.99995 12.1179L2 8.11796V14C2 15.1046 2.89543 16 4 16H16C17.1046 16 18 15.1046 18 14V8.1179Z" fill="currentColor"></path>
                                </svg>
                            </a>
                        </li>
                        <li class="nav-item d-flex align-items-center icon-phone-navbar">
                            <a class="nav-link" data-bss-disabled-mobile="true" data-aos="slide-left" href="link.html">
                                <i class="fa-solid fa-phone"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <main class="page landing-page top-bottom-padding">