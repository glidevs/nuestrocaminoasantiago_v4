<?php

class Recomendaciones extends Controller{
    function __construct(){
        parent::__construct();
        $this->view->render('recomendaciones/index');
    }
}
?>