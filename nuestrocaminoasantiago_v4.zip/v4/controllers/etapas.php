<?php

class Etapas extends Controller{
    function __construct(){
        parent::__construct();
        $this->view->render('etapas/index');
    }
}
?>